import java.util.Scanner;

public class PlayfairCipher {
    private static char[][] matrix = new char[5][5];

    // Build the 5x5 matrix using the keyword
    public static void buildMatrix(String keyword) {
        String alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"; // I and J are treated as the same
        boolean[] used = new boolean[26];
        keyword = keyword.toUpperCase().replace("J", "I");
        StringBuilder matrixContent = new StringBuilder();

        // Add keyword letters
        for (char ch : keyword.toCharArray()) {
            if (ch >= 'A' && ch <= 'Z' && !used[ch - 'A']) {
                matrixContent.append(ch);
                used[ch - 'A'] = true;
            }
        }

        // Add remaining alphabet letters
        for (char ch : alphabet.toCharArray()) {
            if (!used[ch - 'A']) {
                matrixContent.append(ch);
                used[ch - 'A'] = true;
            }
        }

        // Fill the matrix
        for (int i = 0, k = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                matrix[i][j] = matrixContent.charAt(k++);
            }
        }
    }

    // Encrypt a pair of letters
    private static String encryptPair(char a, char b) {
        int[] posA = findPosition(a);
        int[] posB = findPosition(b);

        // Same row
        if (posA[0] == posB[0]) {
            return "" + matrix[posA[0]][(posA[1] + 1) % 5] + matrix[posB[0]][(posB[1] + 1) % 5];
        }
        // Same column
        else if (posA[1] == posB[1]) {
            return "" + matrix[(posA[0] + 1) % 5][posA[1]] + matrix[(posB[0] + 1) % 5][posB[1]];
        }
        // Rectangle
        else {
            return "" + matrix[posA[0]][posB[1]] + matrix[posB[0]][posA[1]];
        }
    }

    // Decrypt a pair of letters
    private static String decryptPair(char a, char b) {
        int[] posA = findPosition(a);
        int[] posB = findPosition(b);

        // Same row
        if (posA[0] == posB[0]) {
            return "" + matrix[posA[0]][(posA[1] + 4) % 5] + matrix[posB[0]][(posB[1] + 4) % 5];
        }
        // Same column
        else if (posA[1] == posB[1]) {
            return "" + matrix[(posA[0] + 4) % 5][posA[1]] + matrix[(posB[0] + 4) % 5][posB[1]];
        }
        // Rectangle
        else {
            return "" + matrix[posA[0]][posB[1]] + matrix[posB[0]][posA[1]];
        }
    }

    // Find the position of a character in the matrix
    private static int[] findPosition(char ch) {
        if (ch == 'J') ch = 'I'; // Treat J as I
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (matrix[i][j] == ch) {
                    return new int[]{i, j};
                }
            }
        }
        return null;
    }

    // Encrypt the plaintext
    public static String encrypt(String plaintext) {
        plaintext = plaintext.toUpperCase().replace("J", "I").replaceAll("[^A-Z]", "");
        StringBuilder encryptedText = new StringBuilder();

        // Ensure even length by adding 'Z' if necessary
        if (plaintext.length() % 2 != 0) {
            plaintext += "Z";
        }

        // Process pairs of letters
        for (int i = 0; i < plaintext.length(); i += 2) {
            char a = plaintext.charAt(i);
            char b = plaintext.charAt(i + 1);
            if (a == b) b = 'X'; // Replace repeated letters in a pair with 'X'
            encryptedText.append(encryptPair(a, b));
        }

        return encryptedText.toString();
    }

    // Decrypt the ciphertext
    public static String decrypt(String ciphertext) {
        ciphertext = ciphertext.toUpperCase();
        StringBuilder decryptedText = new StringBuilder();

        // Process pairs of letters
        for (int i = 0; i < ciphertext.length(); i += 2) {
            char a = ciphertext.charAt(i);
            char b = ciphertext.charAt(i + 1);
            decryptedText.append(decryptPair(a, b));
        }

        return decryptedText.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the keyword
        System.out.print("Enter the keyword: ");
        String keyword = scanner.nextLine();

        // Build the matrix
        buildMatrix(keyword);

        // Display the matrix
        System.out.println("5x5 Matrix:");
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }

        // Input plaintext
        System.out.print("Enter the plaintext: ");
        String plaintext = scanner.nextLine();

        // Encrypt the plaintext
        String encryptedText = encrypt(plaintext);
        System.out.println("Encrypted Text: " + encryptedText);

        // Decrypt the ciphertext
        String decryptedText = decrypt(encryptedText);
        System.out.println("Decrypted Text: " + decryptedText);

        scanner.close();
    }
}
