import java.io.*;
import java.math.BigInteger;
import java.net.*;

public class RSA_client{
	private static final String HOST ="localhost";
	private static final int PORT =12345;
	
	public static void main(String[] args)throws Exception{
			try (Socket socket = new Socket(HOST, PORT);
			ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
			ObjectInputStream in = new ObjectInputStream(socket.getInputStream())){
				
				System.out.println("Connected to server.");
				
				// Recieve public key from the server
				BigInteger e = (BigInteger) in.readObject();
				BigInteger n = (BigInteger) in.readObject();
				System.out.println("Public key recieved: (e="+ e +",n="+ n +")");
				
				//message to send
				String message = "Hi";
				System.out.println("Original message:"+ message);
				
				//Encrypt the message
				BigInteger plaintext = new BigInteger(message.getBytes());
				BigInteger encryptedMessage = plaintext.modPow(e, n);
				System.out.println("Encrypted message:" +encryptedMessage);
				
				//send ecrypted message to the server
				out.writeObject(encryptedMessage);
				
				//recieve response from the server
				String response = (String) in.readObject();
				System.out.println("Response from server:"+response);	
			}
	}
}